import numpy as np

#################################################
# The following lines are edited by master.sage #
#################################################
d = ???
v = np.floor(d/2-1).astype(int)
N = ???
M = ???
def f(lst):
    [m, n, t1, ... , tv] = lst
    return ???
#################################################

# We define a function that computes the gap = n minus the generic slice rank
# We know that this is the highest integer x such that p(x)<=0 and that x<= (d!n)^(1/(d-1)) -2.
def slicegap(n):
    x = np.floor(np.power(np.math.factorial(d)*n,1./(d-1))).astype(int) - 2
    while np.prod([x+i for i in range(2,d+1)])>np.math.factorial(d)*(n-x):
        x = x - 1
    return x

# We compute a list of n's to check
def gapjumps(k,gk,l,gl):
    if gk==gl:
        return []
    else:
        if k+1==l:
            return [k]
        mid = (k+l)/2
        gmid = slicegap(mid)
        return gapjumps(k,gk,mid,gmid)+gapjumps(mid,gmid,l,gl)

nn = gapjumps(1,slicegap(1),N+1,slicegap(N+1))

# A helper function
# input:  l,k
# output: a list of nonnegative integers [t_1, ... , t_l]
#         such that t_1 + ... + t_l = k
def helper(l,k):
    if l==0 and k>0:
        return []
    if k==0:
        return [[0 for i in range(l)]]
    return [[i]+tuple for i in range(k+1) for tuple in helper(l-1,k-i)]

#################################################
# Now the main loop                             #
#################################################

# If the inequality does not hold, we set bad to True
bad = False

while bad==False and len(nn)>0:
    n = nn.pop()
    gap = slicegap(n)
    fmin = f([gap+1,n]+[0 for i in range(v)])
    for m in range(gap+1,min(n+1,M+1)):
        tuples = helper(v,m-gap-1)
        for tuple in tuples:
            if f([m,n]+tuple) <= fmin: # check strict inequality
                if sum(tuple)>0:
                    print("equality holds for (n, d, m-sum(ell)) = " + str((n,d,m-sum(tuple))))
                if f([m,n]+tuple) < fmin:
                    bad = True
    if bad==False:
        print(str(n)+' is good')
    else:
        print(str(n)+' is bad')


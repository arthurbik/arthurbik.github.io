1) Execute master.sage using SAGE.
2) Input d. 
3) Execute worker.py using Python 2.7 with NumPy installed.
4) If the computation finishes without calling a number "bad", then the claim holds for the inputted d. 
